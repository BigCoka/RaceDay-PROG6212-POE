﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;
using System.Security.Claims;

namespace RaceDayAPI.Controllers
{
    [Route("api/events/{eventId}/categories")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public CategoriesController(RaceDayDbContext context)
        {
            _context = context;
        }

        // Anyone can view the categories of a race
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetCategoriesForEvent(int eventId)
        {
            bool eventExists = await _context.Events
                .AnyAsync(e => e.EventID == eventId);

            if (!eventExists)
            {
                return NotFound(new
                {
                    message = "Event does not exist."
                });
            }

            var categories = await _context.Categories
                .Where(c => c.EventID == eventId)
                .Select(c => new
                {
                    c.CategoryID,
                    c.EventID,
                    c.CategoryName,
                    c.DistanceKM,
                    c.EntryFee
                })
                .ToListAsync();

            return Ok(categories);
        }

        // Only the event owner can create categories
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateCategory(
            int eventId,
            [FromBody] Category categoryDto)
        {
            if (!TryGetOrganiserId(out int organiserId))
                return Unauthorized();

            var race = await _context.Events.FindAsync(eventId);

            if (race == null)
                return NotFound(new { message = "Event does not exist." });

            if (race.OrganiserID != organiserId)
                return Forbid();

            if (!IsValidCategory(categoryDto))
                return BadRequest(new
                {
                    message = "Enter a valid category name, distance and entry fee."
                });

            var category = new Category
            {
                EventID = eventId,
                CategoryName = categoryDto.CategoryName.Trim(),
                DistanceKM = categoryDto.DistanceKM,
                EntryFee = categoryDto.EntryFee
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return StatusCode(201, new
            {
                category.CategoryID,
                category.EventID,
                category.CategoryName,
                category.DistanceKM,
                category.EntryFee
            });
        }

        // Only the event owner can update categories
        [HttpPut("{categoryId}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateCategory(
            int eventId,
            int categoryId,
            [FromBody] Category categoryDto)
        {
            if (!TryGetOrganiserId(out int organiserId))
                return Unauthorized();

            var race = await _context.Events.FindAsync(eventId);

            if (race == null)
                return NotFound(new { message = "Event does not exist." });

            if (race.OrganiserID != organiserId)
                return Forbid();

            var category = await _context.Categories
                .FirstOrDefaultAsync(c =>
                    c.CategoryID == categoryId &&
                    c.EventID == eventId);

            if (category == null)
                return NotFound(new { message = "Category not found." });

            if (!IsValidCategory(categoryDto))
                return BadRequest(new
                {
                    message = "Enter a valid category name, distance and entry fee."
                });

            category.CategoryName = categoryDto.CategoryName.Trim();
            category.DistanceKM = categoryDto.DistanceKM;
            category.EntryFee = categoryDto.EntryFee;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                category.CategoryID,
                category.EventID,
                category.CategoryName,
                category.DistanceKM,
                category.EntryFee
            });
        }

        // Only the event owner can delete categories
        [HttpDelete("{categoryId}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteCategory(
            int eventId,
            int categoryId)
        {
            if (!TryGetOrganiserId(out int organiserId))
                return Unauthorized();

            var race = await _context.Events.FindAsync(eventId);

            if (race == null)
                return NotFound(new { message = "Event does not exist." });

            if (race.OrganiserID != organiserId)
                return Forbid();

            var category = await _context.Categories
                .FirstOrDefaultAsync(c =>
                    c.CategoryID == categoryId &&
                    c.EventID == eventId);

            if (category == null)
                return NotFound(new { message = "Category not found." });

            // Prevent deleting categories with registrations
            bool hasEnrolments = await _context.Enrolments
                .AnyAsync(e => e.CategoryID == categoryId);

            if (hasEnrolments)
            {
                return Conflict(new
                {
                    message = "This category has participant enrolments and cannot be deleted."
                });
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Read Organiser ID from the verified JWT
        private bool TryGetOrganiserId(out int organiserId)
        {
            string? userId = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            return int.TryParse(userId, out organiserId);
        }

        // Validate category details
        private static bool IsValidCategory(Category category)
        {
            return !string.IsNullOrWhiteSpace(category.CategoryName)
                && category.CategoryName.Length <= 100
                && category.DistanceKM > 0
                && category.DistanceKM <= 999.99m
                && category.EntryFee >= 0
                && category.EntryFee <= 99999999.99m;
        }
    }
}
