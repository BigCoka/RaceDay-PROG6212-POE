﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;
using System.Security.Claims;

namespace RaceDayAPI.Controllers
{
    [Route("api/enrolments")]
    [ApiController]
    [Authorize]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        public class EnrolmentDto
        {
            public int CategoryID { get; set; }
        }

        public class ResultDto
        {
            public TimeSpan? FinishTime { get; set; }
            public int? OverallPosition { get; set; }
            public string Status { get; set; } = "Finished";
        }

        private bool TryGetUserId(out int userId)
        {
            return int.TryParse(
                User.FindFirstValue(ClaimTypes.NameIdentifier),
                out userId);
        }

        // Participant creates their own enrolment
        [HttpPost]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> CreateEnrolment(
            [FromBody] EnrolmentDto dto)
        {
            if (!TryGetUserId(out int participantId))
                return Unauthorized();

            var category = await _context.Categories
                .FindAsync(dto.CategoryID);

            if (category == null)
                return NotFound(new
                {
                    message = "Category does not exist."
                });

            var existing = await _context.Enrolments
                .FirstOrDefaultAsync(e =>
                    e.ParticipantID == participantId &&
                    e.CategoryID == dto.CategoryID);

            if (existing != null)
                return Conflict(new
                {
                    message = "You are already enrolled in this category."
                });

            var enrolment = new Enrolment
            {
                ParticipantID = participantId,
                CategoryID = dto.CategoryID,
                EnrolmentDate = DateTime.UtcNow,
                Status = "Confirmed"
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return StatusCode(201, new
            {
                enrolment.EnrolmentID,
                enrolment.ParticipantID,
                enrolment.CategoryID,
                enrolment.EnrolmentDate,
                enrolment.Status
            });
        }

        // Participant views their own enrolments
        [HttpGet("my-enrolments/{participantId}")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> GetMyEnrolments(
            int participantId)
        {
            if (!TryGetUserId(out int currentUserId))
                return Unauthorized();

            if (currentUserId != participantId)
                return Forbid();

            var enrolments = await _context.Enrolments
                .Where(e => e.ParticipantID == participantId)
                .Select(e => new
                {
                    e.EnrolmentID,
                    e.ParticipantID,
                    e.CategoryID,
                    e.EnrolmentDate,
                    e.Status,
                    CategoryName = e.Category!.CategoryName,
                    DistanceKM = e.Category.DistanceKM,
                    EntryFee = e.Category.EntryFee,
                    EventID = e.Category.EventID,
                    EventTitle = e.Category.Event!.Title,
                    EventDate = e.Category.Event.EventDate,
                    Location = e.Category.Event.Location
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        // Organiser views registrations for their own event
        [HttpGet("/api/events/{eventId}/enrolments")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventEnrolments(
            int eventId)
        {
            if (!TryGetUserId(out int organiserId))
                return Unauthorized();

            var race = await _context.Events
                .FindAsync(eventId);

            if (race == null)
                return NotFound(new
                {
                    message = "Race event does not exist."
                });

            if (race.OrganiserID != organiserId)
                return Forbid();

            var enrolments = await _context.Enrolments
                .Where(e => e.Category!.EventID == eventId)
                .Select(e => new
                {
                    e.EnrolmentID,
                    e.ParticipantID,
                    ParticipantName = e.Participant!.FullName,
                    ParticipantEmail = e.Participant.Email,
                    e.CategoryID,
                    CategoryName = e.Category!.CategoryName,
                    DistanceKM = e.Category.DistanceKM,
                    e.EnrolmentDate,
                    e.Status
                })
                .OrderBy(e => e.CategoryName)
                .ThenBy(e => e.ParticipantName)
                .ToListAsync();

            return Ok(enrolments);
        }

        // Organiser records results for their own event
        [HttpPost("{enrolmentId}/results")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> RecordResult(
            int enrolmentId,
            [FromBody] ResultDto dto)
        {
            if (!TryGetUserId(out int organiserId))
                return Unauthorized();

            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                .FirstOrDefaultAsync(e =>
                    e.EnrolmentID == enrolmentId);

            if (enrolment == null)
                return NotFound(new
                {
                    message = "Enrolment not found."
                });

            var race = await _context.Events
                .FindAsync(enrolment.Category!.EventID);

            if (race == null)
                return NotFound(new
                {
                    message = "Race event not found."
                });

            if (race.OrganiserID != organiserId)
                return Forbid();

            if (enrolment.Status != "Confirmed")
                return BadRequest(new
                {
                    message = "Results can only be recorded for confirmed enrolments."
                });

            if (dto.Status != "Finished" &&
                dto.Status != "DNF" &&
                dto.Status != "DNS")
            {
                return BadRequest(new
                {
                    message = "Invalid result status."
                });
            }

            if (dto.Status == "Finished" &&
                (!dto.FinishTime.HasValue ||
                 dto.FinishTime.Value <= TimeSpan.Zero))
            {
                return BadRequest(new
                {
                    message = "A valid finish time is required."
                });
            }

            if (dto.Status != "Finished" &&
                (dto.FinishTime.HasValue ||
                 dto.OverallPosition.HasValue))
            {
                return BadRequest(new
                {
                    message = "DNF and DNS results cannot have a finish time or position."
                });
            }

            if (dto.OverallPosition.HasValue &&
                dto.OverallPosition.Value <= 0)
            {
                return BadRequest(new
                {
                    message = "Overall position must be greater than zero."
                });
            }

            bool resultExists = await _context.Results
                .AnyAsync(r => r.EnrolmentID == enrolmentId);

            if (resultExists)
                return Conflict(new
                {
                    message = "A result already exists for this enrolment."
                });

            var result = new Result
            {
                EnrolmentID = enrolmentId,
                FinishTime = dto.FinishTime,
                OverallPosition = dto.OverallPosition,
                Status = dto.Status
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return StatusCode(201, new
            {
                result.EnrolmentID,
                result.FinishTime,
                result.OverallPosition,
                result.Status
            });
        }

        // Participant views their own race results
        [HttpGet("my-results/{participantId}")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> GetMyResults(
            int participantId)
        {
            if (!TryGetUserId(out int currentUserId))
                return Unauthorized();

            if (currentUserId != participantId)
                return Forbid();

            var results = await _context.Results
                .Where(r =>
                    r.Enrolment!.ParticipantID == participantId)
                .Select(r => new
                {
                    r.EnrolmentID,
                    r.FinishTime,
                    r.OverallPosition,
                    r.Status,
                    CategoryName =
                        r.Enrolment!.Category!.CategoryName,
                    EventTitle =
                        r.Enrolment.Category.Event!.Title
                })
                .ToListAsync();

            return Ok(results);
        }
    }
}
