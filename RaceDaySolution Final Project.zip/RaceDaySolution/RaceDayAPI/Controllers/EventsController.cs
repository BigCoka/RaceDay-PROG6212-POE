﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;
using RaceDayAPI.Services;
using System.Security.Claims;

namespace RaceDayAPI.Controllers
{
    [Route("api/events")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly BlobStorageService _blobStorage;

        public EventsController(
            RaceDayDbContext context,
            BlobStorageService blobStorage)
        {
            _context = context;
            _blobStorage = blobStorage;
        }

        // Convert stored blob names into API image URLs
        private static string? GetImageUrl(Event eventItem)
        {
            return string.IsNullOrWhiteSpace(eventItem.ImageUrl)
                ? null
                : $"/api/events/{eventItem.EventID}/image";
        }

        // Anyone can view all race events
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetEvents()
        {
            var events = await _context.Events
                .AsNoTracking()
                .Include(e => e.Organiser)
                .Include(e => e.Categories)
                .Include(e => e.Route)
                .ToListAsync();

            var response = events.Select(e => new
            {
                e.EventID,
                e.OrganiserID,
                e.Title,
                e.Description,
                e.Location,
                e.EventDate,
                e.CreatedAt,
                ImageUrl = GetImageUrl(e),
                e.Organiser,
                e.Categories,
                e.Route
            });

            return Ok(response);
        }

        // Anyone can view a specific race event
        [HttpGet("{id:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetEvent(int id)
        {
            var eventItem = await _context.Events
                .AsNoTracking()
                .Include(e => e.Organiser)
                .Include(e => e.Categories)
                .Include(e => e.Route)
                .FirstOrDefaultAsync(e => e.EventID == id);

            if (eventItem == null)
            {
                return NotFound(new
                {
                    message = "Event does not exist."
                });
            }

            return Ok(new
            {
                eventItem.EventID,
                eventItem.OrganiserID,
                eventItem.Title,
                eventItem.Description,
                eventItem.Location,
                eventItem.EventDate,
                eventItem.CreatedAt,
                ImageUrl = GetImageUrl(eventItem),
                eventItem.Organiser,
                eventItem.Categories,
                eventItem.Route
            });
        }

        // Only authenticated Organisers can create events
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateEvent(
            [FromBody] Event eventDto)
        {
            var userIdValue =
                User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            if (string.IsNullOrWhiteSpace(eventDto.Title) ||
                string.IsNullOrWhiteSpace(eventDto.Location) ||
                eventDto.EventDate == default)
            {
                return BadRequest(new
                {
                    message = "Race name, location and date are required."
                });
            }

            eventDto.OrganiserID = organiserId;
            eventDto.EventID = 0;
            eventDto.CreatedAt = DateTime.UtcNow;
            eventDto.Organiser = null;

            // Images are uploaded separately
            eventDto.ImageUrl = null;

            _context.Events.Add(eventDto);
            await _context.SaveChangesAsync();

            return StatusCode(201, eventDto);
        }

        // Only the event owner can update an event
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateEvent(
            int id,
            [FromBody] Event eventDto)
        {
            var userIdValue =
                User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var existingEvent =
                await _context.Events.FindAsync(id);

            if (existingEvent == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            if (existingEvent.OrganiserID != organiserId)
            {
                return Forbid();
            }

            if (string.IsNullOrWhiteSpace(eventDto.Title) ||
                string.IsNullOrWhiteSpace(eventDto.Location) ||
                eventDto.EventDate == default)
            {
                return BadRequest(new
                {
                    message = "Race name, location and date are required."
                });
            }

            existingEvent.Title = eventDto.Title;
            existingEvent.Description = eventDto.Description;
            existingEvent.Location = eventDto.Location;
            existingEvent.EventDate = eventDto.EventDate;

            await _context.SaveChangesAsync();

            return Ok(existingEvent);
        }

        // Only the event owner can upload an image
        [HttpPost("{id:int}/image")]
        [Authorize(Roles = "Organiser")]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(5 * 1024 * 1024)]
        public async Task<IActionResult> UploadEventImage(
            int id,
            IFormFile image)
        {
            var userIdValue =
                User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var eventItem =
                await _context.Events.FindAsync(id);

            if (eventItem == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            if (eventItem.OrganiserID != organiserId)
            {
                return Forbid();
            }

            if (image == null || image.Length == 0)
            {
                return BadRequest(new
                {
                    message = "Please select an image."
                });
            }

            // Maximum image size: 4 MB
            if (image.Length > 4 * 1024 * 1024)
            {
                return BadRequest(new
                {
                    message = "Image must be smaller than 4 MB."
                });
            }

            // Check permitted file extensions
            var extension =
                Path.GetExtension(image.FileName)
                    .ToLowerInvariant();

            var allowedExtensions = new[]
            {
                ".jpg", ".jpeg", ".png", ".webp"
            };

            if (!allowedExtensions.Contains(extension))
            {
                return BadRequest(new
                {
                    message = "Only JPG, PNG and WebP images are allowed."
                });
            }

            // Check permitted MIME types
            var allowedTypes = new[]
            {
                "image/jpeg",
                "image/png",
                "image/webp"
            };

            if (!allowedTypes.Contains(
                image.ContentType.ToLowerInvariant()))
            {
                return BadRequest(new
                {
                    message = "Invalid image content type."
                });
            }

            // Verify the actual image signature
            byte[] header = new byte[12];

            using (var stream = image.OpenReadStream())
            {
                int bytesRead =
                    await stream.ReadAsync(header.AsMemory());

                if (bytesRead < 12)
                {
                    return BadRequest(new
                    {
                        message = "Invalid image file."
                    });
                }
            }

            bool isJpeg =
                header[0] == 0xFF &&
                header[1] == 0xD8 &&
                header[2] == 0xFF;

            bool isPng =
                header[0] == 0x89 &&
                header[1] == 0x50 &&
                header[2] == 0x4E &&
                header[3] == 0x47 &&
                header[4] == 0x0D &&
                header[5] == 0x0A &&
                header[6] == 0x1A &&
                header[7] == 0x0A;

            bool isWebp =
                header[0] == 0x52 &&
                header[1] == 0x49 &&
                header[2] == 0x46 &&
                header[3] == 0x46 &&
                header[8] == 0x57 &&
                header[9] == 0x45 &&
                header[10] == 0x42 &&
                header[11] == 0x50;

            bool validImage =
                (isJpeg &&
                 (extension == ".jpg" ||
                  extension == ".jpeg") &&
                 image.ContentType == "image/jpeg") ||
                (isPng &&
                 extension == ".png" &&
                 image.ContentType == "image/png") ||
                (isWebp &&
                 extension == ".webp" &&
                 image.ContentType == "image/webp");

            if (!validImage)
            {
                return BadRequest(new
                {
                    message =
                        "The file does not match a supported image format."
                });
            }

            // Upload image to Azure Blob Storage
            string blobName;

            try
            {
                using var stream = image.OpenReadStream();

                blobName = await _blobStorage.UploadImageAsync(
                    stream,
                    image.FileName,
                    image.ContentType);
            }
            catch (Azure.RequestFailedException)
            {
                return StatusCode(502, new
                {
                    message =
                        "Image storage is currently unavailable."
                });
            }

            // Store the blob name in the database
            eventItem.ImageUrl = blobName;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Event image uploaded successfully.",
                eventId = eventItem.EventID,
                imageUrl = GetImageUrl(eventItem)
            });
        }

        // Anyone can view an uploaded event image
        [HttpGet("{id:int}/image")]
        [AllowAnonymous]
        public async Task<IActionResult> GetEventImage(int id)
        {
            var eventItem = await _context.Events
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.EventID == id);

            if (eventItem == null ||
                string.IsNullOrWhiteSpace(eventItem.ImageUrl))
            {
                return NotFound();
            }

            try
            {
                var imageStream =
                    await _blobStorage.DownloadImageAsync(
                        eventItem.ImageUrl);

                // Return the correct image content type
                string extension =
                    Path.GetExtension(eventItem.ImageUrl)
                        .ToLowerInvariant();

                string contentType = extension switch
                {
                    ".jpg" or ".jpeg" => "image/jpeg",
                    ".png" => "image/png",
                    ".webp" => "image/webp",
                    _ => "application/octet-stream"
                };

                return File(imageStream, contentType);
            }
            catch (Azure.RequestFailedException)
            {
                return StatusCode(502, new
                {
                    message =
                        "Unable to retrieve the event image."
                });
            }
        }

        // Only the event owner can delete an event
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var userIdValue =
                User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var eventItem =
                await _context.Events.FindAsync(id);

            if (eventItem == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            if (eventItem.OrganiserID != organiserId)
            {
                return Forbid();
            }

            _context.Events.Remove(eventItem);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
