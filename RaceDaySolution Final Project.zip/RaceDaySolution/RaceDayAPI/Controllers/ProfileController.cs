﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using System.Security.Claims;

namespace RaceDayAPI.Controllers
{
    [Route("api/profile")]
    [ApiController]
    [Authorize(Roles = "Participant")]
    public class ProfileController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ProfileController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/profile/me
        // Returns the logged-in Participant's profile
        [HttpGet("me")]
        public async Task<IActionResult> GetMyProfile()
        {
            // Read the Participant ID from the verified JWT
            string? userIdValue =
                User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized(
                    "Invalid or missing user identity.");
            }

            // Retrieve only the logged-in Participant's details
            var profile = await _context.Users
                .AsNoTracking()
                .Where(u =>
                    u.UserID == userId &&
                    u.Role == "Participant")
                .Select(u => new
                {
                    u.UserID,
                    u.FullName,
                    u.Email,
                    u.Role,
                    u.CreatedAt
                })
                .FirstOrDefaultAsync();

            if (profile == null)
            {
                return NotFound(
                    "Participant profile not found.");
            }

            return Ok(profile);
        }
    }
}
