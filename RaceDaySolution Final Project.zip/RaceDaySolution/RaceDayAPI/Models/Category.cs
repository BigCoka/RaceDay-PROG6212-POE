﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace RaceDayAPI.Models
{


    public class Category
    {
        [Key]
        public int CategoryID { get; set; } // Primary Key, auto-incremented in the database[cite: 4]

        [Required]
        public int EventID { get; set; } // Foreign Key linking back to the parent Event[cite: 4, 5]

        [Required]
        [StringLength(100)]
        public string CategoryName { get; set; } = string.Empty; // Name of the category (e.g., Ultra Marathon, 10km Fun Run)[cite: 5, 8]

        [Required]
        [Column(TypeName = "decimal(5,2)")]
        public decimal DistanceKM { get; set; } // Distance in kilometers (must be greater than 0)[cite: 5]

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal EntryFee { get; set; } // Entry fee in currency (must be 0 or positive)[cite: 5]

        // Navigation properties for Entity Framework relationships
        [ForeignKey("EventID")]
        public Event? Event { get; set; } // The parent event this category belongs to[cite: 5]

        public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>(); // Participant registrations for this category
    }

}
