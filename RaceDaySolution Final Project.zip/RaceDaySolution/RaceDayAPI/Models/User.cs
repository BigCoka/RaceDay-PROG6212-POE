﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace RaceDayAPI.Models
{

    public class User
    {
        [Key]
        public int UserID { get; set; } // Primary Key, auto-incremented in the database

        [Required]
        public string FullName { get; set; } = string.Empty; // Full name of the user (Organiser or Participant)

        [Required]
        public string Email { get; set; } = string.Empty; // Unique email address used for login

        [Required]
        public string PasswordHash { get; set; } = string.Empty; // Securely hashed password using BCrypt

        [Required]
        public string Role { get; set; } = string.Empty; // Restriced role: 'Organiser' or 'Participant'

        public DateTime CreatedAt { get; set; } = DateTime.Now; // Timestamp when the user account was created

        // Navigation properties for Entity Framework relationships
        public ICollection<Event> Events { get; set; } = new List<Event>(); // Events created by this user (if Organiser)
        public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>(); // Races entered by this user (if Participant)
    }

}
