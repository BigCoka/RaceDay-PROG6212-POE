﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly HttpClient _httpClient;

        public AccountController(IHttpClientFactory factory)
        {
            _httpClient = factory.CreateClient("RaceDayAPI");
        }

        // Display registration page
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // Register a new user through RaceDayAPI
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                var response = await _httpClient.PostAsJsonAsync(
                    "api/auth/register", model);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "Registration successful. Please log in.";

                    return RedirectToAction("Login");
                }

                ModelState.AddModelError(
                    "",
                    "Registration failed. Check your details or email.");
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "",
                    "Unable to connect to RaceDayAPI.");
            }

            return View(model);
        }

        // Display login page
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // Log in through RaceDayAPI
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                var response = await _httpClient.PostAsJsonAsync(
                    "api/auth/login", model);

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        "",
                        "Invalid email or password.");

                    return View(model);
                }

                using var json = await JsonDocument.ParseAsync(
                    await response.Content.ReadAsStreamAsync());

                var root = json.RootElement;

                int userId = root.GetProperty("userId").GetInt32();

                string role =
                    root.GetProperty("role").GetString() ?? "";

                string fullName =
                    root.GetProperty("fullName").GetString() ?? "";

                string token =
                    root.GetProperty("token").GetString() ?? "";

                // Check that the API returned a JWT token
                if (string.IsNullOrWhiteSpace(token))
                {
                    ModelState.AddModelError(
                        "",
                        "The API did not provide an authentication token.");

                    return View(model);
                }

                // Check the user's role
                if (role != "Organiser" && role != "Participant")
                {
                    ModelState.AddModelError(
                        "",
                        "Invalid account role.");

                    return View(model);
                }

                // Store user information in the MVC session
                HttpContext.Session.SetInt32("UserID", userId);
                HttpContext.Session.SetString("Role", role);
                HttpContext.Session.SetString("FullName", fullName);

                // Store the JWT token in the server-side session
                HttpContext.Session.SetString("JwtToken", token);

                // Redirect Organisers to their dashboard
                if (role == "Organiser")
                {
                    return RedirectToAction("Index", "Organiser");
                }

                // Redirect Participants to their dashboard
                return RedirectToAction("Index", "Participant");
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "",
                    "Unable to connect to RaceDayAPI.");
            }
            catch (JsonException)
            {
                ModelState.AddModelError(
                    "",
                    "The API returned an invalid response.");
            }
            catch (KeyNotFoundException)
            {
                ModelState.AddModelError(
                    "",
                    "The API response is missing required details.");
            }

            return View(model);
        }

        // Log out and clear the session
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }
    }
}
