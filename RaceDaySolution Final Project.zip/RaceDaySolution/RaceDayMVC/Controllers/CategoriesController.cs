﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public CategoriesController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Check Organiser login and role
        private IActionResult? CheckOrganiser()
        {
            int? userId = HttpContext.Session.GetInt32("UserID");
            string? role = HttpContext.Session.GetString("Role");

            if (userId == null)
                return RedirectToAction("Login", "Account");

            if (role != "Organiser")
                return StatusCode(403, "Organisers only.");

            if (string.IsNullOrWhiteSpace(
                HttpContext.Session.GetString("JwtToken")))
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Account");
            }

            return null;
        }

        // Attach the JWT to API write requests
        private HttpRequestMessage CreateRequest(
            HttpMethod method, string url)
        {
            var request = new HttpRequestMessage(method, url);

            request.Headers.Authorization =
                new AuthenticationHeaderValue(
                    "Bearer",
                    HttpContext.Session.GetString("JwtToken"));

            return request;
        }

        // Show categories for a selected race
        [HttpGet]
        public async Task<IActionResult> Index(int eventId)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            if (eventId <= 0) return BadRequest();

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var race = await client.GetFromJsonAsync<EventViewModel>(
                    $"api/events/{eventId}");

                if (race == null) return NotFound();

                int userId = HttpContext.Session.GetInt32("UserID")!.Value;

                if (race.OrganiserID != userId)
                    return StatusCode(403, "You do not own this race.");

                var categories =
                    await client.GetFromJsonAsync<List<CategoryViewModel>>(
                        $"api/events/{eventId}/categories");

                ViewBag.EventId = eventId;
                ViewBag.EventTitle = race.Title;

                return View(categories ?? new List<CategoryViewModel>());
            }
            catch (HttpRequestException)
            {
                return StatusCode(502, "Unable to connect to RaceDayAPI.");
            }
            catch (JsonException)
            {
                return StatusCode(502, "Invalid API response.");
            }
        }

        // Display Create Category page
        [HttpGet]
        public async Task<IActionResult> Create(int eventId)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            if (eventId <= 0) return BadRequest();

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var race = await client.GetFromJsonAsync<EventViewModel>(
                    $"api/events/{eventId}");

                if (race == null) return NotFound();

                int userId = HttpContext.Session.GetInt32("UserID")!.Value;

                if (race.OrganiserID != userId)
                    return StatusCode(403, "You do not own this race.");

                return View(new CategoryViewModel
                {
                    EventID = eventId
                });
            }
            catch (HttpRequestException)
            {
                return StatusCode(502, "Unable to load race details.");
            }
            catch (JsonException)
            {
                return StatusCode(502, "Invalid API response.");
            }
        }

        // Create a category through RaceDayAPI
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryViewModel model)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            if (model.EventID <= 0) return BadRequest();

            if (!ModelState.IsValid) return View(model);

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = CreateRequest(
                    HttpMethod.Post,
                    $"api/events/{model.EventID}/categories");

                request.Content = JsonContent.Create(model);

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Category created successfully!";
                    return RedirectToAction("Index",
                        new { eventId = model.EventID });
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "You do not own this race.");

                ModelState.AddModelError(
                    "", "Unable to create the category.");
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "", "Unable to connect to RaceDayAPI.");
            }

            return View(model);
        }

        // Display Edit Category page
        [HttpGet]
        public async Task<IActionResult> Edit(int eventId, int categoryId)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var race = await client.GetFromJsonAsync<EventViewModel>(
                    $"api/events/{eventId}");

                if (race == null) return NotFound();

                int userId = HttpContext.Session.GetInt32("UserID")!.Value;

                if (race.OrganiserID != userId)
                    return StatusCode(403, "You do not own this race.");

                var categories =
                    await client.GetFromJsonAsync<List<CategoryViewModel>>(
                        $"api/events/{eventId}/categories");

                var category = categories?.FirstOrDefault(
                    c => c.CategoryID == categoryId);

                if (category == null) return NotFound();

                return View(category);
            }
            catch (HttpRequestException)
            {
                return StatusCode(502, "Unable to load category.");
            }
            catch (JsonException)
            {
                return StatusCode(502, "Invalid API response.");
            }
        }

        // Save category changes
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CategoryViewModel model)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            if (model.EventID <= 0 || model.CategoryID <= 0)
                return BadRequest();

            if (!ModelState.IsValid) return View(model);

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = CreateRequest(
                    HttpMethod.Put,
                    $"api/events/{model.EventID}/categories/{model.CategoryID}");

                request.Content = JsonContent.Create(model);

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Category updated successfully!";
                    return RedirectToAction("Index",
                        new { eventId = model.EventID });
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "You do not own this race.");

                if (response.StatusCode == HttpStatusCode.NotFound)
                    return NotFound("Category not found.");

                ModelState.AddModelError(
                    "", "Unable to update the category.");
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "", "Unable to connect to RaceDayAPI.");
            }

            return View(model);
        }

        // Delete a category
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int eventId, int categoryId)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            if (eventId <= 0 || categoryId <= 0)
                return BadRequest();

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = CreateRequest(
                    HttpMethod.Delete,
                    $"api/events/{eventId}/categories/{categoryId}");

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Category deleted successfully!";
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }
                else if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return StatusCode(403, "You do not own this race.");
                }
                else if (response.StatusCode == HttpStatusCode.Conflict)
                {
                    TempData["Error"] =
                        "This category has enrolments and cannot be deleted.";
                }
                else
                {
                    TempData["Error"] = "Unable to delete category.";
                }
            }
            catch (HttpRequestException)
            {
                TempData["Error"] = "Unable to connect to RaceDayAPI.";
            }

            return RedirectToAction("Index", new { eventId });
        }
    }
}
