﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class EnrolmentsController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public EnrolmentsController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Display registrations for an Organiser's race
        [HttpGet]
        public async Task<IActionResult> Index(int eventId)
        {
            // Check that the user is logged in
            int? userId = HttpContext.Session.GetInt32("UserID");
            string? role = HttpContext.Session.GetString("Role");
            string? token = HttpContext.Session.GetString("JwtToken");

            if (userId == null || string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            // Only Organisers can access this page
            if (role != "Organiser")
                return StatusCode(403, "Organisers only.");

            if (eventId <= 0)
                return BadRequest("Invalid event ID.");

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                // Verify that the event belongs to this Organiser
                using var eventResponse =
                    await client.GetAsync($"api/events/{eventId}");

                if (eventResponse.StatusCode == HttpStatusCode.NotFound)
                    return NotFound("Race event not found.");

                if (!eventResponse.IsSuccessStatusCode)
                    return StatusCode(502, "Unable to load race details.");

                var race = await eventResponse.Content
                    .ReadFromJsonAsync<EventViewModel>();

                if (race == null)
                    return NotFound();

                if (race.OrganiserID != userId.Value)
                    return StatusCode(403, "You do not own this race.");

                // Request enrolments using the Organiser's JWT
                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    $"api/events/{eventId}/enrolments");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                using var response = await client.SendAsync(request);

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "Access denied.");

                if (response.StatusCode == HttpStatusCode.NotFound)
                    return NotFound("Race event not found.");

                if (!response.IsSuccessStatusCode)
                    return StatusCode(502, "Unable to load enrolments.");

                var enrolments = await response.Content
                    .ReadFromJsonAsync<List<EnrolmentViewModel>>();

                ViewBag.EventId = eventId;
                ViewBag.EventTitle = race.Title;

                return View(enrolments ?? new List<EnrolmentViewModel>());
            }
            catch (HttpRequestException)
            {
                return StatusCode(
                    502, "Unable to connect to RaceDayAPI.");
            }
            catch (JsonException)
            {
                return StatusCode(
                    502, "Invalid response from RaceDayAPI.");
            }
        }
    }
}
