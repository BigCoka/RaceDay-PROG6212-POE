
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Diagnostics;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory _factory;

        public HomeController(
            ILogger<HomeController> logger,
            IHttpClientFactory factory)
        {
            _logger = logger;
            _factory = factory;
        }

        // Display the homepage with the next upcoming race
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            EventViewModel? nextRace = null;

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var events = await client.GetFromJsonAsync
                    <List<EventViewModel>>("api/events");

                nextRace = events?
                    .Where(e => e.EventDate >= DateTime.Today)
                    .OrderBy(e => e.EventDate)
                    .FirstOrDefault();
            }
            catch (HttpRequestException ex)
            {
                _logger.LogWarning(
                    ex,
                    "Unable to connect to RaceDayAPI.");

                ViewBag.Error =
                    "Upcoming races are temporarily unavailable.";
            }
            catch (JsonException ex)
            {
                _logger.LogWarning(
                    ex,
                    "Unable to read race event data.");

                ViewBag.Error =
                    "Unable to load upcoming races.";
            }

            return View(nextRace);
        }

        // Privacy page
        public IActionResult Privacy()
        {
            return View();
        }

        // Error page
        [ResponseCache(
            Duration = 0,
            Location = ResponseCacheLocation.None,
            NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id
                    ?? HttpContext.TraceIdentifier
            });
        }
    }
}
