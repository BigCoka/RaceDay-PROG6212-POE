﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class MyEnrolmentsController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public MyEnrolmentsController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Display registrations for the logged-in Participant
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            int? userId =
                HttpContext.Session.GetInt32("UserID");

            string? role =
                HttpContext.Session.GetString("Role");

            string? token =
                HttpContext.Session.GetString("JwtToken");

            // Check that the Participant is logged in
            if (userId == null || string.IsNullOrWhiteSpace(token))
            {
                return RedirectToAction("Login", "Account");
            }

            // Only Participants can view their own enrolments
            if (role != "Participant")
            {
                return StatusCode(
                    403,
                    "Access Denied: Participants only.");
            }

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    $"api/enrolments/my-enrolments/{userId.Value}");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                using var response = await client.SendAsync(request);

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();

                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return StatusCode(
                        403,
                        "You cannot access these enrolments.");
                }

                if (!response.IsSuccessStatusCode)
                {
                    ViewBag.Error =
                        "Unable to load your race registrations.";

                    return View(new List<MyEnrolmentViewModel>());
                }

                var enrolments = await response.Content
                    .ReadFromJsonAsync<List<MyEnrolmentViewModel>>();

                return View(
                    enrolments ?? new List<MyEnrolmentViewModel>());
            }
            catch (HttpRequestException)
            {
                ViewBag.Error =
                    "Unable to connect to RaceDayAPI.";
            }
            catch (JsonException)
            {
                ViewBag.Error =
                    "Unable to read your registration information.";
            }

            return View(new List<MyEnrolmentViewModel>());
        }
    }
}
