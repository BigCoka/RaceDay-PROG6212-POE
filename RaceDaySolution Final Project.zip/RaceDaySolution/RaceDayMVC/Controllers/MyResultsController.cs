﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class MyResultsController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public MyResultsController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Display results for the logged-in Participant
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            int? userId =
                HttpContext.Session.GetInt32("UserID");

            string? role =
                HttpContext.Session.GetString("Role");

            string? token =
                HttpContext.Session.GetString("JwtToken");

            // Check whether the Participant is logged in
            if (userId == null ||
                string.IsNullOrWhiteSpace(token))
            {
                return RedirectToAction("Login", "Account");
            }

            // Only Participants may view their own results
            if (role != "Participant")
            {
                return StatusCode(
                    403,
                    "Access Denied: Participants only.");
            }

            try
            {
                var client =
                    _factory.CreateClient("RaceDayAPI");

                // Request results for the logged-in Participant
                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    $"api/enrolments/my-results/{userId.Value}");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue(
                        "Bearer", token);

                using var response =
                    await client.SendAsync(request);

                if (response.StatusCode ==
                    HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();

                    return RedirectToAction(
                        "Login", "Account");
                }

                if (response.StatusCode ==
                    HttpStatusCode.Forbidden)
                {
                    return StatusCode(
                        403,
                        "You cannot access these results.");
                }

                if (!response.IsSuccessStatusCode)
                {
                    ViewBag.Error =
                        "Unable to load your race results.";

                    return View(new List<MyResultViewModel>());
                }

                var results = await response.Content
                    .ReadFromJsonAsync<List<MyResultViewModel>>();

                return View(
                    results ?? new List<MyResultViewModel>());
            }
            catch (HttpRequestException)
            {
                ViewBag.Error =
                    "Unable to connect to RaceDayAPI.";
            }
            catch (JsonException)
            {
                ViewBag.Error =
                    "Unable to read your race results.";
            }

            return View(new List<MyResultViewModel>());
        }
    }
}
