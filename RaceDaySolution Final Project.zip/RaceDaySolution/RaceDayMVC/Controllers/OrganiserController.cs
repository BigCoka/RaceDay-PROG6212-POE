﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public OrganiserController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Check whether the user is an Organiser
        private IActionResult? CheckOrganiser()
        {
            int? userId = HttpContext.Session.GetInt32("UserID");
            string? role = HttpContext.Session.GetString("Role");

            if (userId == null)
                return RedirectToAction("Login", "Account");

            if (role != "Organiser")
                return StatusCode(403, "Access Denied: Organisers only.");

            return null;
        }

        // Create an API request with the JWT token
        private HttpRequestMessage CreateAuthenticatedRequest(
            HttpMethod method, string url)
        {
            string? token = HttpContext.Session.GetString("JwtToken");

            var request = new HttpRequestMessage(method, url);

            if (!string.IsNullOrWhiteSpace(token))
            {
                request.Headers.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }

            return request;
        }

        // Organiser Dashboard
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var events = await client
                    .GetFromJsonAsync<List<EventViewModel>>("api/events");

                int userId = HttpContext.Session.GetInt32("UserID")!.Value;

                var organiserEvents = events?
                    .Where(e => e.OrganiserID == userId)
                    .ToList() ?? new List<EventViewModel>();

                return View(organiserEvents);
            }
            catch (HttpRequestException)
            {
                ViewBag.Error = "Unable to connect to RaceDayAPI.";
            }
            catch (JsonException)
            {
                ViewBag.Error = "Unable to read event data from RaceDayAPI.";
            }

            return View(new List<EventViewModel>());
        }

        // Display Create Event page
        [HttpGet]
        public IActionResult CreateEvent()
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            return View(new EventViewModel());
        }

        // Create a new event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEvent(EventViewModel model)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            string? token = HttpContext.Session.GetString("JwtToken");

            if (string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            if (string.IsNullOrWhiteSpace(model.Title) ||
                string.IsNullOrWhiteSpace(model.Location) ||
                model.EventDate == default)
            {
                ModelState.AddModelError(
                    "", "Please complete all required fields.");

                return View(model);
            }

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = CreateAuthenticatedRequest(
                    HttpMethod.Post, "api/events");

                request.Content = JsonContent.Create(model);

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "Race event created successfully!";

                    return RedirectToAction("Index");
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "Access Denied.");

                ModelState.AddModelError(
                    "", "Unable to create the race event.");
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "", "Unable to connect to RaceDayAPI.");
            }

            return View(model);
        }

        // Display Edit Event page
        [HttpGet]
        public async Task<IActionResult> EditEvent(int id)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var race = await client
                    .GetFromJsonAsync<EventViewModel>($"api/events/{id}");

                if (race == null)
                    return NotFound();

                int userId = HttpContext.Session.GetInt32("UserID")!.Value;

                if (race.OrganiserID != userId)
                    return StatusCode(403, "You cannot edit this event.");

                return View(race);
            }
            catch (HttpRequestException)
            {
                return NotFound("Race event could not be found.");
            }
            catch (JsonException)
            {
                return StatusCode(502, "Invalid API response.");
            }
        }

        // Save edited event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEvent(
            int id, EventViewModel model)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            if (id != model.EventID)
                return BadRequest("Event ID mismatch.");

            string? token = HttpContext.Session.GetString("JwtToken");

            if (string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            if (string.IsNullOrWhiteSpace(model.Title) ||
                string.IsNullOrWhiteSpace(model.Location) ||
                model.EventDate == default)
            {
                ModelState.AddModelError(
                    "", "Please complete all required fields.");

                return View(model);
            }

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = CreateAuthenticatedRequest(
                    HttpMethod.Put, $"api/events/{id}");

                request.Content = JsonContent.Create(model);

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "Race event updated successfully!";

                    return RedirectToAction("Index");
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "You cannot edit this event.");

                if (response.StatusCode == HttpStatusCode.NotFound)
                    return NotFound("Race event not found.");

                ModelState.AddModelError(
                    "", "Unable to update the race event.");
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "", "Unable to connect to RaceDayAPI.");
            }

            return View(model);
        }

        // Delete an event owned by this Organiser
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var access = CheckOrganiser();
            if (access != null) return access;

            string? token = HttpContext.Session.GetString("JwtToken");

            if (string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = CreateAuthenticatedRequest(
                    HttpMethod.Delete, $"api/events/{id}");

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "Race event deleted successfully!";

                    return RedirectToAction("Index");
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "You cannot delete this event.");

                if (response.StatusCode == HttpStatusCode.NotFound)
                    return NotFound("Race event not found.");

                TempData["Error"] = "Unable to delete the race event.";
            }
            catch (HttpRequestException)
            {
                TempData["Error"] = "Unable to connect to RaceDayAPI.";
            }

            return RedirectToAction("Index");
        }
    }
}
