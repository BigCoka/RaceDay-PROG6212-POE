﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public ParticipantController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Check whether the logged-in user is a Participant
        private IActionResult? CheckParticipant()
        {
            int? userId = HttpContext.Session.GetInt32("UserID");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            string? role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
            {
                return StatusCode(
                    403,
                    "Access Denied: Participants only.");
            }

            return null;
        }

        // Participant Dashboard
        [HttpGet]
        public IActionResult Index()
        {
            var access = CheckParticipant();

            if (access != null)
            {
                return access;
            }

            return View();
        }

        // Browse and filter race events
        [HttpGet]
        public async Task<IActionResult> Browse(
            string? search,
            string? location)
        {
            var access = CheckParticipant();

            if (access != null)
            {
                return access;
            }

            ViewBag.Search = search;
            ViewBag.Location = location;

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                var events = await client.GetFromJsonAsync
                    <List<EventViewModel>>("api/events");

                var filteredEvents =
                    events ?? new List<EventViewModel>();

                if (!string.IsNullOrWhiteSpace(search))
                {
                    filteredEvents = filteredEvents
                        .Where(e => e.Title.Contains(
                            search,
                            StringComparison.OrdinalIgnoreCase))
                        .ToList();
                }

                if (!string.IsNullOrWhiteSpace(location))
                {
                    filteredEvents = filteredEvents
                        .Where(e => e.Location.Contains(
                            location,
                            StringComparison.OrdinalIgnoreCase))
                        .ToList();
                }

                filteredEvents = filteredEvents
                    .OrderBy(e => e.EventDate)
                    .ToList();

                return View(filteredEvents);
            }
            catch (HttpRequestException)
            {
                ViewBag.Error = "Unable to connect to RaceDayAPI.";
            }
            catch (JsonException)
            {
                ViewBag.Error = "Unable to read race event data.";
            }

            return View(new List<EventViewModel>());
        }

        // Display a selected race and its categories
        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var access = CheckParticipant();

            if (access != null)
            {
                return access;
            }

            if (id <= 0)
            {
                return BadRequest("Invalid event ID.");
            }

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                // Load the selected race
                using var eventResponse =
                    await client.GetAsync($"api/events/{id}");

                if (eventResponse.StatusCode == HttpStatusCode.NotFound)
                {
                    return NotFound("Race event not found.");
                }

                if (!eventResponse.IsSuccessStatusCode)
                {
                    return StatusCode(
                        502,
                        "Unable to load race details.");
                }

                var race = await eventResponse.Content
                    .ReadFromJsonAsync<EventViewModel>();

                if (race == null)
                {
                    return NotFound("Race event not found.");
                }

                // Load categories for this race
                using var categoryResponse =
                    await client.GetAsync($"api/events/{id}/categories");

                if (!categoryResponse.IsSuccessStatusCode)
                {
                    return StatusCode(
                        502,
                        "Unable to load race categories.");
                }

                var categories = await categoryResponse.Content
                    .ReadFromJsonAsync<List<CategoryViewModel>>();

                // Combine event details and categories
                var model = new EventDetailsViewModel
                {
                    Event = race,
                    Categories = categories ?? new List<CategoryViewModel>()
                };

                return View(model);
            }
            catch (HttpRequestException)
            {
                return StatusCode(
                    502,
                    "Unable to connect to RaceDayAPI.");
            }
            catch (JsonException)
            {
                return StatusCode(
                    502,
                    "Invalid response from RaceDayAPI.");
            }
        }
    }
}
