﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class ParticipantEnrolmentsController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public ParticipantEnrolmentsController(
            IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Register the logged-in Participant for a race category
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enrol(
            EnrolmentRequestViewModel model)
        {
            int? userId =
                HttpContext.Session.GetInt32("UserID");

            string? role =
                HttpContext.Session.GetString("Role");

            string? token =
                HttpContext.Session.GetString("JwtToken");

            if (userId == null ||
                string.IsNullOrWhiteSpace(token))
            {
                return RedirectToAction("Login", "Account");
            }

            if (role != "Participant")
            {
                return StatusCode(
                    403,
                    "Access Denied: Participants only.");
            }

            if (!ModelState.IsValid)
            {
                TempData["Error"] =
                    "Please select a valid race category.";

                return RedirectToAction(
                    "Browse", "Participant");
            }

            try
            {
                var client =
                    _factory.CreateClient("RaceDayAPI");

                // Confirm that the category belongs to this event
                using var categoryResponse =
                    await client.GetAsync(
                        $"api/events/{model.EventID}/categories");

                if (!categoryResponse.IsSuccessStatusCode)
                {
                    TempData["Error"] =
                        "Unable to verify the selected category.";

                    return RedirectToAction(
                        "Details",
                        "Participant",
                        new { id = model.EventID });
                }

                var categories = await categoryResponse.Content
                    .ReadFromJsonAsync<List<CategoryViewModel>>();

                bool categoryExists =
                    categories?.Any(c =>
                        c.CategoryID == model.CategoryID) == true;

                if (!categoryExists)
                {
                    TempData["Error"] =
                        "The selected category does not belong to this race.";

                    return RedirectToAction(
                        "Details",
                        "Participant",
                        new { id = model.EventID });
                }

                // Submit the enrolment using the Participant's JWT
                using var request = new HttpRequestMessage(
                    HttpMethod.Post,
                    "api/enrolments");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue(
                        "Bearer", token);

                request.Content = JsonContent.Create(new
                {
                    model.CategoryID
                });

                using var response =
                    await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "You have successfully enrolled in this race category!";
                }
                else if (response.StatusCode ==
                         HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();

                    return RedirectToAction(
                        "Login", "Account");
                }
                else if (response.StatusCode ==
                         HttpStatusCode.Forbidden)
                {
                    return StatusCode(
                        403, "Participant access denied.");
                }
                else if (response.StatusCode ==
                         HttpStatusCode.Conflict)
                {
                    TempData["Error"] =
                        "You are already enrolled in this race category.";
                }
                else
                {
                    TempData["Error"] =
                        "Unable to complete registration. Please try again.";
                }
            }
            catch (HttpRequestException)
            {
                TempData["Error"] =
                    "Unable to connect to RaceDayAPI.";
            }
            catch (JsonException)
            {
                TempData["Error"] =
                    "Unable to read category information.";
            }

            return RedirectToAction(
                "Details",
                "Participant",
                new { id = model.EventID });
        }
    }
}
