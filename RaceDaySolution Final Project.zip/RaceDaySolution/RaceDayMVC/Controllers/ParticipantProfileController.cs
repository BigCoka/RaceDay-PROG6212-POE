﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class ParticipantProfileController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public ParticipantProfileController(
            IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Display the logged-in Participant's profile
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            int? userId =
                HttpContext.Session.GetInt32("UserID");

            string? role =
                HttpContext.Session.GetString("Role");

            string? token =
                HttpContext.Session.GetString("JwtToken");

            // Check whether the user is logged in
            if (userId == null ||
                string.IsNullOrWhiteSpace(token))
            {
                return RedirectToAction("Login", "Account");
            }

            // Only Participants can access this page
            if (role != "Participant")
            {
                return StatusCode(
                    403,
                    "Access Denied: Participants only.");
            }

            try
            {
                var client =
                    _factory.CreateClient("RaceDayAPI");

                // Request the logged-in Participant's profile
                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    "api/profile/me");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue(
                        "Bearer", token);

                using var response =
                    await client.SendAsync(request);

                if (response.StatusCode ==
                    HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();

                    return RedirectToAction(
                        "Login", "Account");
                }

                if (response.StatusCode ==
                    HttpStatusCode.Forbidden)
                {
                    return StatusCode(
                        403,
                        "You cannot access this profile.");
                }

                if (response.StatusCode ==
                    HttpStatusCode.NotFound)
                {
                    return NotFound(
                        "Participant profile not found.");
                }

                if (!response.IsSuccessStatusCode)
                {
                    ViewBag.Error =
                        "Unable to load your profile.";

                    return View(new ParticipantProfileViewModel());
                }

                var profile = await response.Content
                    .ReadFromJsonAsync<ParticipantProfileViewModel>();

                if (profile == null)
                {
                    ViewBag.Error =
                        "No profile information was returned.";

                    return View(new ParticipantProfileViewModel());
                }

                return View(profile);
            }
            catch (HttpRequestException)
            {
                ViewBag.Error =
                    "Unable to connect to RaceDayAPI.";
            }
            catch (JsonException)
            {
                ViewBag.Error =
                    "Unable to read your profile information.";
            }

            return View(new ParticipantProfileViewModel());
        }
    }
}
