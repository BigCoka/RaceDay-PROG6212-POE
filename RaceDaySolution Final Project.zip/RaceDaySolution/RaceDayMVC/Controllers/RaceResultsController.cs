﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class RaceResultsController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public RaceResultsController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        [HttpGet]
        public async Task<IActionResult> Index(int eventId)
        {
            int? userId = HttpContext.Session.GetInt32("UserID");
            string? role = HttpContext.Session.GetString("Role");
            string? token = HttpContext.Session.GetString("JwtToken");

            if (userId == null || string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            if (role != "Organiser")
                return StatusCode(403, "Organisers only.");

            if (eventId <= 0)
                return BadRequest("Invalid event ID.");

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                // Confirm the Organiser owns the event
                using var eventResponse =
                    await client.GetAsync($"api/events/{eventId}");

                if (eventResponse.StatusCode == HttpStatusCode.NotFound)
                    return NotFound("Race event not found.");

                if (!eventResponse.IsSuccessStatusCode)
                    return StatusCode(502, "Unable to load race details.");

                var race = await eventResponse.Content
                    .ReadFromJsonAsync<EventViewModel>();

                if (race == null)
                    return NotFound();

                if (race.OrganiserID != userId.Value)
                    return StatusCode(403, "You do not own this race.");

                // Load participants enrolled in this race
                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    $"api/events/{eventId}/enrolments");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                using var response = await client.SendAsync(request);

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }

                if (response.StatusCode == HttpStatusCode.Forbidden)
                    return StatusCode(403, "Access denied.");

                if (!response.IsSuccessStatusCode)
                    return StatusCode(502, "Unable to load participants.");

                var enrolments = await response.Content
                    .ReadFromJsonAsync<List<EnrolmentViewModel>>();

                ViewBag.EventId = eventId;
                ViewBag.EventTitle = race.Title;

                return View(enrolments ?? new List<EnrolmentViewModel>());
            }
            catch (HttpRequestException)
            {
                return StatusCode(502, "Unable to connect to RaceDayAPI.");
            }
            catch (JsonException)
            {
                return StatusCode(502, "Invalid API response.");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Record(
            int eventId,
            ResultViewModel model)
        {
            int? userId = HttpContext.Session.GetInt32("UserID");
            string? role = HttpContext.Session.GetString("Role");
            string? token = HttpContext.Session.GetString("JwtToken");

            if (userId == null || string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            if (role != "Organiser")
                return StatusCode(403, "Organisers only.");

            if (eventId <= 0 || model.EnrolmentID <= 0)
                return BadRequest("Invalid event or enrolment ID.");

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please enter valid result details.";
                return RedirectToAction("Index", new { eventId });
            }

            try
            {
                var client = _factory.CreateClient("RaceDayAPI");

                using var request = new HttpRequestMessage(
                    HttpMethod.Post,
                    $"api/enrolments/{model.EnrolmentID}/results");

                request.Headers.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                request.Content = JsonContent.Create(new
                {
                    model.FinishTime,
                    model.OverallPosition,
                    model.Status
                });

                using var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Race result recorded successfully!";
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Login", "Account");
                }
                else if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    return StatusCode(403, "Access denied.");
                }
                else if (response.StatusCode == HttpStatusCode.Conflict)
                {
                    TempData["Error"] =
                        "A result has already been recorded for this participant.";
                }
                else
                {
                    TempData["Error"] =
                        "Unable to record the result. Check the time, position and status.";
                }
            }
            catch (HttpRequestException)
            {
                TempData["Error"] = "Unable to connect to RaceDayAPI.";
            }

            return RedirectToAction("Index", new { eventId });
        }
    }
}
