﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class CategoryViewModel
    {
        public int CategoryID { get; set; }

        public int EventID { get; set; }

        [Required(ErrorMessage = "Please enter a category name.")]
        [StringLength(100)]
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the race distance.")]
        [Range(typeof(decimal), "0.01", "999.99",
            ErrorMessage = "Distance must be greater than zero.")]
        [Display(Name = "Distance (KM)")]
        public decimal DistanceKM { get; set; }

        [Required(ErrorMessage = "Please enter the entry fee.")]
        [Range(typeof(decimal), "0", "99999999.99",
            ErrorMessage = "Entry fee cannot be negative.")]
        [Display(Name = "Entry Fee (R)")]
        public decimal EntryFee { get; set; }
    }
}
