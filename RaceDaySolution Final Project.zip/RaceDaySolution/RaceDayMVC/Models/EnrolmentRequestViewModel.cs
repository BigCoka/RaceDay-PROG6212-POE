﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class EnrolmentRequestViewModel
    {
        [Required]
        [Range(1, int.MaxValue)]
        public int CategoryID { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int EventID { get; set; }
    }
}
