﻿
using System.Collections.Generic;

namespace RaceDayMVC.Models
{
    public class EventDetailsViewModel
    {
        // Details of the selected race event
        public EventViewModel Event { get; set; }
            = new EventViewModel();

        // Categories available for this race
        public List<CategoryViewModel> Categories { get; set; }
            = new List<CategoryViewModel>();
    }
}
