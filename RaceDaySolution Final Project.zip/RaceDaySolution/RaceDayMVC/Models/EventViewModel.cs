﻿
namespace RaceDayMVC.Models
{
    public class EventViewModel
    {
        public int EventID { get; set; }

        public int OrganiserID { get; set; }

        public string Title { get; set; } = string.Empty;

        public string? Description { get; set; }

        public string Location { get; set; } = string.Empty;

        public DateTime EventDate { get; set; }

        public DateTime CreatedAt { get; set; }

        // URL used to retrieve the event image from RaceDayAPI
        public string? ImageUrl { get; set; }
    }
}
