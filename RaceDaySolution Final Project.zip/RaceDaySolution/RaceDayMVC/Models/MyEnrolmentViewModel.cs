﻿
using System;

namespace RaceDayMVC.Models
{
    public class MyEnrolmentViewModel
    {
        public int EnrolmentID { get; set; }

        public int ParticipantID { get; set; }

        public int CategoryID { get; set; }

        public int EventID { get; set; }

        public string EventTitle { get; set; } = string.Empty;

        public string CategoryName { get; set; } = string.Empty;

        public string Location { get; set; } = string.Empty;

        public DateTime EventDate { get; set; }

        public DateTime EnrolmentDate { get; set; }

        public decimal DistanceKM { get; set; }

        public decimal EntryFee { get; set; }

        public string Status { get; set; } = string.Empty;
    }
}
