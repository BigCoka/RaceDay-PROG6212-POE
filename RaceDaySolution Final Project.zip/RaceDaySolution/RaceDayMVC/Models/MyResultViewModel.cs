﻿
using System;

namespace RaceDayMVC.Models
{
    public class MyResultViewModel
    {
        public int ResultID { get; set; }

        public int EnrolmentID { get; set; }

        public int EventID { get; set; }

        public string EventTitle { get; set; } = string.Empty;

        public string CategoryName { get; set; } = string.Empty;

        public DateTime EventDate { get; set; }

        public string Location { get; set; } = string.Empty;

        public int? Position { get; set; }

        public TimeSpan? FinishTime { get; set; }

        public string Status { get; set; } = string.Empty;
    }
}
