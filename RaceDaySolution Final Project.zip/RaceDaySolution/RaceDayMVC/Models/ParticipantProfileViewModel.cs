﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class ParticipantProfileViewModel
    {
        public int UserID { get; set; }

        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Display(Name = "Email Address")]
        public string Email { get; set; } = string.Empty;

        public string Role { get; set; } = string.Empty;

        [Display(Name = "Member Since")]
        public DateTime CreatedAt { get; set; }
    }
}
