﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class ResultViewModel
    {
        public int ResultID { get; set; }

        [Required]
        public int EnrolmentID { get; set; }

        public string ParticipantName { get; set; } = string.Empty;

        public string EventTitle { get; set; } = string.Empty;

        public string CategoryName { get; set; } = string.Empty;

        public TimeSpan? FinishTime { get; set; }

        [Range(1, int.MaxValue,
            ErrorMessage = "Position must be greater than zero.")]
        public int? OverallPosition { get; set; }

        [Required]
        public string Status { get; set; } = "Finished";
    }
}
