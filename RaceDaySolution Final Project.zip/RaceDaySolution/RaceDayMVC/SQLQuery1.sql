﻿
IF COL_LENGTH('dbo.Events', 'ImageUrl') IS NULL
BEGIN
    ALTER TABLE dbo.Events
    ADD ImageUrl NVARCHAR(2048) NULL;
END;
